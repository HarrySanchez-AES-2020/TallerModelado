package edu.co.javeriana.modelado.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import edu.co.javeriana.modelado.model.Convenio;

@Repository
public interface ConvenioDao extends JpaRepository<Convenio, Integer> {
	
	@Query(value = "SELECT * FROM convenio where convenio = ?1 and operacion = ?2", nativeQuery = true)
	Optional<Convenio> getConvenioByIdAndOperacion(String convenio, String operacion);

}
