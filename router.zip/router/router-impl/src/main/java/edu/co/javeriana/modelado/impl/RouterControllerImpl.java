package edu.co.javeriana.modelado.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import edu.co.javeriana.modelado.api.EnrutadorController;
import edu.co.javeriana.modelado.model.Convenio;
import edu.co.javeriana.modelado.service.ConvenioService;

@Component
public class RouterControllerImpl implements EnrutadorController{
	
	@Autowired
	private ConvenioService convenioService;

	@Override
	public ResponseEntity<Convenio> getEnrutadorByOperacion(@PathVariable String refPago, @PathVariable
	        String operacion) {
		Convenio c = convenioService.getConvenioByIdConvenio(refPago, operacion).get();
		return ResponseEntity.ok(c);
	}

}
