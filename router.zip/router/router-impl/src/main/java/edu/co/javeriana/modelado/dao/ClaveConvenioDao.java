package edu.co.javeriana.modelado.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.co.javeriana.modelado.model.ClaveConvenio;

@Repository
public interface ClaveConvenioDao extends JpaRepository<ClaveConvenio, Integer> {

}
