package edu.co.javeriana.modelado.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.co.javeriana.modelado.dao.ConvenioDao;
import edu.co.javeriana.modelado.model.ClaveConvenio;
import edu.co.javeriana.modelado.model.Convenio;
import edu.co.javeriana.modelado.service.ClaveConvenioService;
import edu.co.javeriana.modelado.service.ConvenioService;

@Service
public class ConvenioServiceImpl implements ConvenioService {

	@Autowired
	private ConvenioDao convenioDao;

	@Autowired
	private ClaveConvenioService claveConvenioService;

	@Override
	public Optional<Convenio> getConvenioByIdConvenio(String idConvenio, String operacion) {
		Optional<Convenio> convenio = Optional.empty();
		List<ClaveConvenio> claves = claveConvenioService.getAllClaves();
		ClaveConvenio idClave = null;

		for (ClaveConvenio clave : claves) {
			Pattern pat = Pattern.compile(clave.getClave());
			Matcher mat = pat.matcher(idConvenio);
			if (mat.lookingAt()) {
				idClave = clave;
				break;
			}
		}

		convenio = convenioDao.getConvenioByIdAndOperacion(idClave.getConvenio(), operacion);

		return convenio;

	}

}
