package edu.co.javeriana.modelado.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.co.javeriana.modelado.dao.ClaveConvenioDao;
import edu.co.javeriana.modelado.model.ClaveConvenio;
import edu.co.javeriana.modelado.service.ClaveConvenioService;

@Service
public class ClaveConvenioServiceImpl implements ClaveConvenioService {

	@Autowired
	private ClaveConvenioDao claveConvenioDao;

	@Override
	public List<ClaveConvenio> getAllClaves() {
		return claveConvenioDao.findAll();
	}

}
