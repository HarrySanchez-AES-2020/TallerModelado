package edu.co.javeriana.modelado.service;

import java.util.Optional;

import edu.co.javeriana.modelado.model.Convenio;

public interface ConvenioService {
	
	Optional<Convenio> getConvenioByIdConvenio(String idConvenio, String operacion);

}
