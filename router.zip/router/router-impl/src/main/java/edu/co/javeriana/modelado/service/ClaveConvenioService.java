package edu.co.javeriana.modelado.service;

import java.util.List;

import edu.co.javeriana.modelado.model.ClaveConvenio;

public interface ClaveConvenioService {
	
	List<ClaveConvenio> getAllClaves();

}
