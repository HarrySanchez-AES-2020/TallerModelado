package edu.co.javeriana.modelado.service.impl;

import java.io.StringReader;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import edu.co.javeriana.modelado.dao.PlantillasConveniosDao;
import edu.co.javeriana.modelado.model.InfoTransformar;
import edu.co.javeriana.modelado.model.PlantillaConvenio;
import edu.co.javeriana.modelado.service.PlantillasConveniosService;

@Service
public class PlantillasConveniosServiceImpl implements PlantillasConveniosService {

	@Autowired
	private PlantillasConveniosDao plantillasConveniosDao;

	private static final String REQ = "req";

	@Override
	public String getPlantillaConvenio(InfoTransformar infoTransformar) {
		List<PlantillaConvenio> plantillas = plantillasConveniosDao.findAll();
		for (PlantillaConvenio plantilla : plantillas) {
			if (plantilla.getTipo().equals(infoTransformar.getTipo())
					&& plantilla.getOperacion().equals(infoTransformar.getOperacion())
					&& plantilla.getConvenio().equals(infoTransformar.getConvenio()))
				return transformaPlantilla(plantilla, infoTransformar.getInfo());
		}
		return null;
	}

	private String transformaPlantilla(PlantillaConvenio plantilla, String info) {
		if (plantilla.getOperacion().equals(REQ)) {
			String[] data = info.split(";");
			String[] c = plantilla.getClave().split(";");
			for (int i = 0; i < c.length; i++) {
				plantilla.setPlantilla(plantilla.getPlantilla().replace(c[i], data[i]));
			}
			return plantilla.getPlantilla();
		} else {
			return convertirXMLString(info, plantilla.getClave());
		}

	}

	private String convertirXMLString(String xml, String clave) {
		Document doc = convertStringToXMLDocument(xml);
		return doc.getElementsByTagName(clave).item(0).getTextContent();
	}

	private static Document convertStringToXMLDocument(String xmlString) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
