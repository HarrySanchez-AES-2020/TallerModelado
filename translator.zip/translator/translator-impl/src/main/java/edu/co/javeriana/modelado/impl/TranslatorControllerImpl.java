package edu.co.javeriana.modelado.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import edu.co.javeriana.modelado.api.TraductorController;
import edu.co.javeriana.modelado.model.InfoTransformar;
import edu.co.javeriana.modelado.service.PlantillasConveniosService;

@Component
public class TranslatorControllerImpl implements TraductorController {

	@Autowired
	private PlantillasConveniosService plantillasConveniosService;

	@Override
	public ResponseEntity<String> updateTraductor(InfoTransformar infoTransformar) {
		return ResponseEntity.ok(plantillasConveniosService.getPlantillaConvenio(infoTransformar));
	}

}
