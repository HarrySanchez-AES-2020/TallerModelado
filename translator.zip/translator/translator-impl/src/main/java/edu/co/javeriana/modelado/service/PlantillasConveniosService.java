package edu.co.javeriana.modelado.service;

import edu.co.javeriana.modelado.model.InfoTransformar;

public interface PlantillasConveniosService {
	
	String getPlantillaConvenio(InfoTransformar infoTransformar);

}
