package edu.co.javeriana.modelado.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.co.javeriana.modelado.model.PlantillaConvenio;

public interface PlantillasConveniosDao extends JpaRepository<PlantillaConvenio, Integer> {

}
