package co.edu.javeriana.aes.modval;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
@EnableAutoConfiguration
public class SpingBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpingBootApplication.class, args);
	}
}
