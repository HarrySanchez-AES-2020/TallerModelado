package co.edu.javeriana.aes.modval.services;

import co.edu.javeriana.aes.modval.services.EnrutadorProcessor;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;
@Component
public class Orquestador extends RouteBuilder{
	
	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		restConfiguration()
		.enableCORS(true)
		.component("jetty")
		.port(8082)
		.bindingMode(RestBindingMode.auto);
		
		rest("/api/orquestador")
		.get("/{refPago}/{operacion}").id("orquestador-consultar-service")
		.to("direct:enrutador")
		
		
		.post("/pagarservicio/").id("orquestador-pay-service")
		.to("direct:enrutador-payservice");
		
		
		from("direct:enrutador")
		//Step 1, consultar a traves de un GET al enrutador
		//devuelve =>"tipoServcio","metodo","endPointLegado","operacion","idCon
	
		.routeId("OrquestadorStep1")
		.log(LoggingLevel.INFO, "Headers antes del Req a Enrutador ${in.headers}")
		.setHeader(Exchange.HTTP_METHOD,simple("GET"))
		.setHeader(Exchange.CONTENT_TYPE,constant("application/json"))
		
		.toD("http://127.0.0.1:8090/api/enrutador/${in.headers.refPago}/${in.headers.operacion}"+"?bridgeEndpoint=true")
		.convertBodyTo(String.class)
		.log("Body Despues del Response del enrutador => ${body}")
		.log("Headers Despues del Response del enrutador => ${in.headers}")
		.unmarshal().json(JsonLibrary.Jackson)
		.to("direct:despachador");
		
		from("direct:despachador")
		.routeId("OrquestadorStep2")
		//Step 1, consultar a traves de un post al despachador el valor de factura
		//devuelve =>"tipoServcio","metodo","endPointLegado","operacion","idCon
		
		.marshal().json(JsonLibrary.Jackson)
		.log("Body a enviar al despachador: ${body}")
		.setHeader(Exchange.HTTP_METHOD,simple("POST"))
		.setHeader(Exchange.CONTENT_TYPE,constant("application/json"))
		.process(new EnrutadorProcessor())
		//.unmarshal().json(JsonLibrary.Jackson)
		
		.log("Body a enviar al despachador: ${body}")
		//.toD("https://92ef77f8-d261-4018-836a-9cc762039fcc.mock.pstmn.io/despachador/"+"?bridgeEndpoint=true")
        //.to("http://127.0.0.1:8092/api/despachador/?bridgeEndpoint=true")
		.convertBodyTo(String.class)
		.unmarshal().json(JsonLibrary.Jackson)
		.log("Body Despues del Response del despachador => ${body}");
		
		
		from("direct:enrutador-payservice")
		//Step 1, Pagar a traves de un POST al enrutador
		//devuelve =>"tipoServcio","metodo","endPointLegado","operacion","idCon
		.routeId("OrquestadorPayStep1")
		//.log("Body antes del Req a Enrutador => ${body}")
		.marshal().json(JsonLibrary.Jackson)
		.process( e -> e.getIn().getHeaders().clear())
		.setHeader(Exchange.HTTP_METHOD,simple("POST"))
		.setHeader(Exchange.CONTENT_TYPE,constant("application/json"))
		.toD("https://92ef77f8-d261-4018-836a-9cc762039fcc.mock.pstmn.io/enutadorpost?bridgeEndpoint=true")
		//to("http://127.0.0.1:8090/api/enrutador/${header.refPago}?bridgeEndpoint=true");
		.convertBodyTo(String.class)
		.log("Body Despues del Response del enrutador => ${body}")
		.unmarshal().json(JsonLibrary.Jackson)
		.to("direct:despachador-payservice");
		
		
		
		
		from("direct:despachador-payservice")
		.routeId("OrquestadorPayStep2")
		//Step 1, Pagar a traves de un post al despachador el valor de factura
		//devuelve =>"tipoServcio","metodo","endPointLegado","operacion","idCon
		
		.marshal().json(JsonLibrary.Jackson)
		.process(exchange -> exchange.getIn().setBody(exchange.getIn().getBody()))
		
		.log("Body a enviar al despachador: ${body}")
		.setHeader(Exchange.HTTP_METHOD, constant("POST"))
        .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
		.to("https://92ef77f8-d261-4018-836a-9cc762039fcc.mock.pstmn.io/despachador")
        //.to("http://127.0.0.1:8081/adapter/check/")
		.convertBodyTo(String.class)
		.unmarshal().json(JsonLibrary.Jackson)
		.log("Body Despues del Response del despachador => ${body}")
		.unmarshal().json(JsonLibrary.Jackson);
		
		
	}

}
