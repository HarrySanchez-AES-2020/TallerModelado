package co.edu.javeriana.aes.modval.services;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;


public class EnrutadorProcessor implements Processor{

	public void process(Exchange exchange) throws Exception{
		//System.out.println(exchange.getIn().getBody(String.class));	
		String msgin = exchange.getIn().getBody(String.class);
		String header = exchange.getIn().getHeader("refPago", String.class);
		
		
		 System.out.println(header);	
		
		Pattern pattern = Pattern.compile("\"tiposervicio\":\"([a-z]+)\"");
		Matcher matcher = pattern.matcher(msgin);
		String tipoServicio= "";
		  if(matcher.find()) {
			  tipoServicio= matcher.group(1);
		      } else {
		         tipoServicio= "hola";
		         
		      }
		  
			 pattern = Pattern.compile("\"metodo\":\"([a-z]+)\"");
			 matcher = pattern.matcher(msgin);
			String metodo = "";
			  if(matcher.find()) {
				  metodo= matcher.group(1);
			      } else {
			    	  metodo= "hola";
			         
			      }
		
			  pattern = Pattern.compile("\"endpoint\":\"([a-zA-Z0-9 : \\- \\/]+)\"");
				 matcher = pattern.matcher(msgin);
				String endPoint = "";
				  if(matcher.find()) {
					  endPoint= matcher.group(1);
				      } else {
				    	  endPoint= "hola";
				      }
	    
				  pattern = Pattern.compile("\"operacion\":\"([a-z]+)\"");
					 matcher = pattern.matcher(msgin);
					String operacion = "";
					  if(matcher.find()) {
						  operacion= matcher.group(1);
					      } else {
					    	  operacion= "hola";
					      }
	
					  pattern = Pattern.compile("\"convenio\":\"([a-z]+)\"");
						 matcher = pattern.matcher(msgin);
						String IdConvenio = "";
						  if(matcher.find()) {
							  IdConvenio= matcher.group(1);
						      } else {
						    	  IdConvenio= "hola";
						      }
	

						  if(tipoServicio.equals("rest"))
						  {
							  pattern = Pattern.compile("\\/idFactura");
							  matcher = pattern.matcher(endPoint);
							  endPoint = "";

							  if(matcher.find()) {
								  endPoint=matcher.replaceAll("/"+header);     
							  } 
						  }

						  
	    StringBuilder msgout = new StringBuilder();
	    
	    msgout.append("{\"refPago\":").append("\"").append(header).append("\",");
	    msgout.append("\"tipoServicio\":").append("\"").append(tipoServicio).append("\",");
	    msgout.append("\"metodo\":").append("\"").append(metodo).append("\",");
	    msgout.append("\"endPoint\":").append("\"").append(endPoint).append("\",");
	    msgout.append("\"operacion\":").append("\"").append(operacion).append("\",");
	    msgout.append("\"IdConvenio\":").append("\"").append(IdConvenio).append("\"");
	    msgout.append("}");
	    
	    exchange.getIn().setBody(msgout.toString());
	    
	    System.out.println(exchange.getIn().getBody(String.class));	
		
	}
	
}