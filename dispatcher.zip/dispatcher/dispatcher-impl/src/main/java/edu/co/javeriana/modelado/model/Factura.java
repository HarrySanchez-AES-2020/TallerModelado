package edu.co.javeriana.modelado.model;

public class Factura {

	private String refPago;
	private Double valorPago;

	public Factura(String refPago, Double valorPago) {
		super();
		this.refPago = refPago;
		this.valorPago = valorPago;
	}

	public Factura() {
		super();
	}

	public String getRefPago() {
		return refPago;
	}

	public void setRefPago(String refPago) {
		this.refPago = refPago;
	}

	public Double getValorPago() {
		return valorPago;
	}

	public void setValorPago(Double valorPago) {
		this.valorPago = valorPago;
	}

}
