package edu.co.javeriana.modelado.service;

import edu.co.javeriana.modelado.model.InfoConvenios;
import edu.co.javeriana.modelado.model.RespuestaConvenio;

public interface ConectarConveniosService {
	
	RespuestaConvenio conectarConvenio(InfoConvenios infoConvenios);

}
