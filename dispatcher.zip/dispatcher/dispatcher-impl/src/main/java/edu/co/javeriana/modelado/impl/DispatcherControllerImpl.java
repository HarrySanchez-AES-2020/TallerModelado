package edu.co.javeriana.modelado.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import edu.co.javeriana.modelado.api.DespacharController;
import edu.co.javeriana.modelado.model.InfoConvenios;
import edu.co.javeriana.modelado.model.RespuestaConvenio;
import edu.co.javeriana.modelado.service.ConectarConveniosService;

@Component
public class DispatcherControllerImpl implements DespacharController {

	@Autowired
	private ConectarConveniosService conectarConvenioService;

	@Override
	public ResponseEntity<RespuestaConvenio> updateDespachar(InfoConvenios infoConvenios) {
		return ResponseEntity.ok(conectarConvenioService.conectarConvenio(infoConvenios));
	}

}
