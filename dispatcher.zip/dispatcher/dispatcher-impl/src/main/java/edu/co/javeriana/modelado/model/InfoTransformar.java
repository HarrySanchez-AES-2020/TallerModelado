package edu.co.javeriana.modelado.model;

public class InfoTransformar {
	
	private String operacion;
	private String convenio;
	private String tipo;
	private String info;

	public InfoTransformar(String operacion, String convenio, String tipo, String info) {
		super();
		this.operacion = operacion;
		this.convenio = convenio;
		this.tipo = tipo;
		this.info = info;
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
