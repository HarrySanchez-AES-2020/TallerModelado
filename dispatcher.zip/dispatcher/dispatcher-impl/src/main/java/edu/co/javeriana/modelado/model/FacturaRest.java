package edu.co.javeriana.modelado.model;

public class FacturaRest {

	private String idFactura;
	private Double valorFactura;

	public FacturaRest(String idFactura, Double valorFactura) {
		super();
		this.idFactura = idFactura;
		this.valorFactura = valorFactura;
	}

	public String getIdFactura() {
		return idFactura;
	}

	public void setIdFactura(String idFactura) {
		this.idFactura = idFactura;
	}

	public Double getValorFactura() {
		return valorFactura;
	}

	public void setValorFactura(Double valorFactura) {
		this.valorFactura = valorFactura;
	}

}
