package edu.co.javeriana.modelado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouterApp {

	public static void main(String[] args) {
		SpringApplication.run(RouterApp.class, args);
    }

}
