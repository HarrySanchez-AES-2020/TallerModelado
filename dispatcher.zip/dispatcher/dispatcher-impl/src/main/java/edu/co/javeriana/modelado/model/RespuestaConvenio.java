package edu.co.javeriana.modelado.model;

public class RespuestaConvenio {

	private Factura factura;
	private String mensaje;

	public Factura getFactura() {
		return factura;
	}

	public void setFactura(Factura factura) {
		this.factura = factura;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
