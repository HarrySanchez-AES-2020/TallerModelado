package edu.co.javeriana.modelado.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;

import edu.co.javeriana.modelado.model.Factura;
import edu.co.javeriana.modelado.model.FacturaRest;
import edu.co.javeriana.modelado.model.InfoConvenios;
import edu.co.javeriana.modelado.model.InfoTransformar;
import edu.co.javeriana.modelado.model.RespuestaConvenio;
import edu.co.javeriana.modelado.service.ConectarConveniosService;

@Service
public class ConectarConvenioServiceImpl implements ConectarConveniosService {

	private static final String SOAP = "soap";
	private static final String POST = "post";
	private static final String REQ = "req";
	private static final String RES = "res";
	private static final String CONSULTAR = "consultar";
	private static final String TRADUCTOR = "http://localhost:8082/api/traductor";

	@Override
	public RespuestaConvenio conectarConvenio(InfoConvenios infoConvenios) {
		RespuestaConvenio respuestaConvenio = new RespuestaConvenio();
		if (infoConvenios.getTipoServicio().equals(SOAP)) {
			consumirServicioSOAP(respuestaConvenio, infoConvenios);
		} else {
			consumirServicioREST(respuestaConvenio, infoConvenios);
		}
		return respuestaConvenio;
	}

	private void consumirServicioREST(RespuestaConvenio respuestaConvenio, InfoConvenios infoConvenios) {
		Gson gson = new Gson();
		if (infoConvenios.getOperacion().equals(CONSULTAR)) {
			FacturaRest resp = gson.fromJson(
					conexionRest(infoConvenios.getEndPoint().concat("/").concat(infoConvenios.getRefPago()),
							infoConvenios.getMetodo(), gson.toJson(new Factura(infoConvenios.getRefPago(), 0.0))),
					FacturaRest.class);
			respuestaConvenio.setFactura(mapperFactura(resp));
		} else {
			respuestaConvenio.setMensaje(conexionRest(
					infoConvenios.getEndPoint().concat("/").concat(infoConvenios.getRefPago()),
					infoConvenios.getMetodo(), gson.toJson(
							mapperFacturaRest(new Factura(infoConvenios.getRefPago(), infoConvenios.getValorPago())))));
		}

	}

	private void consumirServicioSOAP(RespuestaConvenio respuestaConvenio, InfoConvenios infoConvenios) {
		InfoTransformar SOAPRequest;
		if (infoConvenios.getOperacion().equals(CONSULTAR)) {
			SOAPRequest = new InfoTransformar(REQ, infoConvenios.getIdConvenio(), infoConvenios.getOperacion(),
					infoConvenios.getRefPago());
		} else {
			SOAPRequest = new InfoTransformar(REQ, infoConvenios.getIdConvenio(), infoConvenios.getOperacion(),
					infoConvenios.getRefPago().concat(";").concat(infoConvenios.getValorPago().toString()));
		}
		Gson gson = new Gson();
		String request = conexionRest(TRADUCTOR, POST, gson.toJson(SOAPRequest));
		String response = invocarServicioSoap(request, infoConvenios);
		InfoTransformar SOAPResponse = new InfoTransformar(RES, infoConvenios.getIdConvenio(),
				infoConvenios.getOperacion(), response);
		String respuestaTraducida = conexionRest(TRADUCTOR, POST, gson.toJson(SOAPResponse));
		System.out.println(respuestaTraducida);
		if (infoConvenios.getOperacion().equals(CONSULTAR)) {
			infoConvenios.setValorPago(Double.valueOf(respuestaTraducida));
			respuestaConvenio.setFactura(new Factura(infoConvenios.getRefPago(), infoConvenios.getValorPago()));
		} else {
			respuestaConvenio.setMensaje(respuestaTraducida);
		}
	}

	@SuppressWarnings("deprecation")
	private String invocarServicioSoap(String request, InfoConvenios infoConvenios) {
		try {
			HttpClient httpclient = HttpClients.createDefault();
			StringEntity strEntity;
			strEntity = new StringEntity(request, "text/xml", "UTF-8");
			HttpPost post = new HttpPost(infoConvenios.getEndPoint());
			post.setHeader("SOAPAction", infoConvenios.getOperacion());
			post.setEntity(strEntity);
			HttpResponse response = httpclient.execute(post);
			HttpEntity respEntity = response.getEntity();
			String content = EntityUtils.toString(respEntity);
			System.out.println(content);
			return content;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private String conexionRest(String direccionUrl, String metodo, String body) {
		HttpURLConnection conn = null;
		try {
			URL url = new URL(direccionUrl);
			conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			if (metodo.equals(POST)) {
				conn.setRequestMethod(HttpMethod.POST.name());
				conn.setRequestProperty("Content-Type", "application/json");
				OutputStream os = conn.getOutputStream();
				if (metodo.equals(POST))
					os.write(body.getBytes());
				os.flush();
			} else
				conn.setRequestMethod(HttpMethod.GET.name());

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String line = null;
			String message = new String();
			while ((line = br.readLine()) != null) {
				message += line;
			}
			conn.disconnect();
			return message;
		} catch (ProtocolException e) {
			e.printStackTrace();
			conn.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private Factura mapperFactura(FacturaRest response) {
		return new Factura(response.getIdFactura(), response.getValorFactura());
	}

	private FacturaRest mapperFacturaRest(Factura request) {
		return new FacturaRest(request.getRefPago(), request.getValorPago());
	}

}
